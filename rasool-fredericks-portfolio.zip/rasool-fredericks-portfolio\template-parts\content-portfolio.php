<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rasool Fredericks - Front-End Developer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Montserrat:wght@600;700;800&family=Roboto:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/styles.css">
    <script>
        (function () {
            try {
                if (localStorage.getItem('rf-theme') === 'light') {
                    document.documentElement.setAttribute('data-theme', 'light');
                }
            } catch (e) {}
        })();
    </script>
</head>
<body>
    <canvas id="starfield" aria-hidden="true"></canvas>
    <!-- Sticky Header & Navigation -->
    <header class="header">
        <nav class="nav container">
            <div class="nav__logo">
                <span class="nav__logo-text">Rasool Fredericks</span>
                <span class="nav__status">
                    <span class="nav__status-dot"></span>
                    <span class="nav__status-text">Available for Hire</span>
                </span>
            </div>
            <div class="nav__actions">
                <button class="theme-toggle" id="themeToggle" type="button" aria-label="Toggle light and dark mode" aria-pressed="false">
                    <i class="fa-solid fa-sun"></i>
                </button>
                <button class="nav__toggle" id="navToggle" aria-label="Open menu" aria-expanded="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <div class="nav__menu" id="navMenu">
                    <ul class="nav__links">
                        <li><a href="#about" class="nav__link">About</a></li>
                        <li><a href="#experience" class="nav__link">Experience</a></li>
                        <li><a href="#skills" class="nav__link">Skills</a></li>
                        <li><a href="#projects" class="nav__link">Projects</a></li>
                        <li><a href="#education" class="nav__link">Education</a></li>
                        <li><a href="#contact" class="nav__link">Contact</a></li>
                    </ul>
                    <a href="<?php echo get_template_directory_uri(); ?>/assets/Rasool_Fredericks_Resume.pdf" target="_blank" rel="noopener" class="nav__cta">Resume / CV</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <!-- Hero Section -->
        <section class="hero" id="hero">
            <div class="container hero__grid">
                <div class="hero__content">
                    <h1 class="hero__headline">Front-End Developer building clean, responsive web experiences.</h1>
                    <p class="hero__subheadline">Currently studying Web / Front-End Development at Life-Choices Academy, with 1.5 years of hands-on, project-based experience turning designs into polished interfaces.</p>
                    <div class="hero__actions">
                        <a href="#projects" class="btn btn--primary">View Work</a>
                        <a href="#contact" class="btn btn--outline">Contact Me</a>
                    </div>
                </div>
                <div class="hero__visual" aria-hidden="true">
                    <div class="hero__scene">
                        <div class="glass-card gc1">
                            <div class="gc__code">
                                <span class="gc__line">const app = createApp()</span>
                                <span class="gc__line">app.mount('#app')</span>
                                <span class="gc__line gc__line--accent">{ ui: 'ready' }</span>
                            </div>
                        </div>
                        <div class="glass-card gc2">
                            <div class="gc__dots">
                                <span></span><span></span><span></span>
                            </div>
                            <span class="gc__label">Components</span>
                        </div>
                        <div class="glass-card gc3">
                            <div class="gc__bars">
                                <span></span><span></span><span></span><span></span>
                            </div>
                            <span class="gc__label">Responsive UI</span>
                        </div>
                        <div class="node n1"></div>
                        <div class="node n2"></div>
                        <div class="node n3"></div>
                        <div class="glow g1"></div>
                        <div class="glow g2"></div>
                    </div>
                </div>
            </div>
        </section>

        <!-- About Section -->
        <section class="section about" id="about">
            <div class="container about__grid">
                <div class="about__left">
                    <div class="avatar" id="avatarFlip" role="button" tabindex="0" aria-pressed="false" aria-label="Flip between formal and casual photo">
                        <div class="avatar__border"></div>
                        <div class="avatar__flip">
                            <div class="avatar__face avatar__face--front"><img class="avatar__img" src="<?php echo get_template_directory_uri(); ?>/assets/profile.png" alt="Rasool Fredericks portrait" loading="lazy"></div>
                            <div class="avatar__face avatar__face--back"><img class="avatar__img" src="<?php echo get_template_directory_uri(); ?>/assets/profile-casual.png" alt="Rasool Fredericks casual portrait" loading="lazy" onerror="this.onerror=null;this.src='<?php echo get_template_directory_uri(); ?>/assets/profile.png'"></div>
                        </div>
                    </div>
                </div>
                <div class="about__right">
                    <h2 class="section__title">About Me</h2>
                    <p class="section__lead">I'm a front-end developer with 1.5 years of hands-on experience building responsive, user-focused web interfaces. I'm currently studying Web / Front-End Development at Life-Choices Academy, where I sharpen my skills through practical, project-based coursework.</p>
                    <h3 class="about__subtitle">Professional Overview</h3>
                    <div class="about__cards">
                        <article class="info-card">
                            <div class="info-card__icon"><i class="fa-solid fa-bolt"></i></div>
                            <h4 class="info-card__title">1.5 Years Hands-On</h4>
                            <p class="info-card__text">Building responsive interfaces through project-based work.</p>
                        </article>
                        <article class="info-card">
                            <div class="info-card__icon"><i class="fa-solid fa-layer-group"></i></div>
                            <h4 class="info-card__title">Front-End Focus</h4>
                            <p class="info-card__text">HTML, CSS, JavaScript, React &amp; Vue.js.</p>
                        </article>
                        <article class="info-card">
                            <div class="info-card__icon"><i class="fa-solid fa-graduation-cap"></i></div>
                            <h4 class="info-card__title">Web Development Student</h4>
                            <p class="info-card__text">Studying Web / Front-End Development at Life-Choices Academy.</p>
                        </article>
                    </div>
                </div>
            </div>
        </section>

        <!-- Experience Section -->
        <section class="section experience" id="experience">
            <div class="container">
                <h2 class="section__title">Experience</h2>
                <p class="section__lead">Hands-on experience building for the web, from coursework to real projects.</p>
                <ol class="timeline">
                    <li class="timeline__item">
                        <div class="timeline__marker" aria-hidden="true"></div>
                        <div class="timeline__content">
                            <div class="timeline__head">
                                <h3 class="timeline__role">Front-End Developer</h3>
                                <span class="timeline__period">2025 &ndash; Present</span>
                            </div>
                            <ul class="timeline__points">
                                <li>Build responsive, accessible interfaces from design mockups using HTML, CSS and JavaScript.</li>
                                <li>Develop reusable UI components with modern frameworks such as React and Vue.js.</li>
                                <li>Collaborate in team projects using Git and GitHub, managing branches and pull requests.</li>
                                <li>Write clean, maintainable code and ensure consistent, cross-browser layouts.</li>
                            </ul>
                        </div>
                    </li>
                    <li class="timeline__item">
                        <div class="timeline__marker" aria-hidden="true"></div>
                        <div class="timeline__content">
                            <div class="timeline__head">
                                <h3 class="timeline__role">Web / Front-End Development Student</h3>
                                <span class="timeline__period">2025 &ndash; Present</span>
                            </div>
                            <ul class="timeline__points">
                                <li>Studying Web / Front-End Development at Life-Choices Academy.</li>
                                <li>Apply best practices in responsive design, accessibility and version control.</li>
                                <li>Complete practical projects that simulate real-world development workflows.</li>
                            </ul>
                        </div>
                    </li>
                </ol>
            </div>
        </section>

        <!-- Skills Section -->
        <section class="section skills" id="skills">
            <div class="container">
                <h2 class="section__title">Skills</h2>
                <div class="skills__grid">
                    <article class="skill-card">
                        <h3 class="skill-card__title">Languages</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fab fa-html5"></i> HTML5</span>
                            <span class="skill-pill"><i class="fab fa-css3-alt"></i> CSS3</span>
                            <span class="skill-pill"><i class="fab fa-js"></i> JavaScript</span>
                            <span class="skill-pill"><i class="fa-solid fa-code"></i> TypeScript</span>
                            <span class="skill-pill"><i class="fa-solid fa-hashtag"></i> Markdown</span>
                        </div>
                    </article>
                    <article class="skill-card">
                        <h3 class="skill-card__title">Frameworks &amp; Libraries</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fab fa-react"></i> React</span>
                            <span class="skill-pill"><i class="fab fa-vuejs"></i> Vue.js</span>
                            <span class="skill-pill"><i class="fab fa-bootstrap"></i> Bootstrap</span>
                            <span class="skill-pill"><i class="fa-solid fa-wind"></i> Tailwind CSS</span>
                            <span class="skill-pill"><i class="fab fa-sass"></i> SASS</span>
                        </div>
                    </article>
                    <article class="skill-card">
                        <h3 class="skill-card__title">Front-End Practices</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fab fa-git-alt"></i> Git</span>
                            <span class="skill-pill"><i class="fab fa-github"></i> GitHub</span>
                            <span class="skill-pill"><i class="fa-solid fa-code"></i> VS Code</span>
                            <span class="skill-pill"><i class="fab fa-npm"></i> npm</span>
                            <span class="skill-pill"><i class="fab fa-figma"></i> Figma</span>
                        </div>
                    </article>
                    <article class="skill-card">
                        <h3 class="skill-card__title">Tools &amp; Workflow</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fa-solid fa-mobile-screen-button"></i> Responsive Design</span>
                            <span class="skill-pill"><i class="fa-solid fa-universal-access"></i> Accessibility</span>
                            <span class="skill-pill"><i class="fa-solid fa-plug"></i> REST APIs</span>
                            <span class="skill-pill"><i class="fa-solid fa-pen-ruler"></i> UI/UX Basics</span>
                            <span class="skill-pill"><i class="fa-solid fa-display"></i> Cross-Browser Testing</span>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Projects Section -->
        <section class="section projects" id="projects">
            <div class="container">
                <h2 class="section__title">Projects</h2>
                <div class="projects__grid">
                    <article class="project-card">
                        <div class="project-card__thumb">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/project-hr-system.png" alt="ModernTech HR Management System dashboard" loading="lazy">
                        </div>
                        <div class="project-card__body">
                            <span class="project-card__tag">Full-Stack HR Platform</span>
                            <h3 class="project-card__title">ModernTech HR Management System</h3>
                            <p class="project-card__desc">A full-stack HR management app for tracking employees, attendance, payroll, time off, and performance reviews. Built with role-based JWT auth and a normalised MySQL schema. I owned the payroll module.</p>
                            <div class="project-card__stack">
                                <span class="stack-pill">Node.js</span>
                                <span class="stack-pill">Express</span>
                                <span class="stack-pill">MySQL</span>
                                <span class="stack-pill">JWT</span>
                            </div>
                            <div class="project-card__actions">
                                <a href="https://moderntech-hr-frontend.onrender.com" target="_blank" rel="noopener" class="proj-link" aria-label="Live site"><i class="fa-solid fa-arrow-up-right-from-square"></i> Live Site</a>
                                <a href="https://github.com/nikitamullerr/Group-4_HRSystem_Project2" target="_blank" rel="noopener" class="proj-link" aria-label="GitHub repo"><i class="fab fa-github"></i> GitHub Repo</a>
                            </div>
                        </div>
                    </article>

                    <article class="project-card">
                        <div class="project-card__thumb">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/project-applydirect.png" alt="ApplyDirect-SA application portal homepage" loading="lazy">
                        </div>
                        <div class="project-card__body">
                            <span class="project-card__tag">Full-Stack Web Platform</span>
                            <h3 class="project-card__title">ApplyDirect-SA</h3>
                            <p class="project-card__desc">A centralised tertiary application portal and career directory for South African students. Aggregates course details and institutional requirements with dynamic search and filtering.</p>
                            <div class="project-card__stack">
                                <span class="stack-pill">Vue.js</span>
                                <span class="stack-pill">Bootstrap 5</span>
                                <span class="stack-pill">Express</span>
                                <span class="stack-pill">MySQL</span>
                            </div>
                            <div class="project-card__actions">
                                <a href="https://github.com/stephanbennett42-ctrl/applydirect-sa" target="_blank" rel="noopener" class="proj-link" aria-label="GitHub repo"><i class="fab fa-github"></i> GitHub Repo</a>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Education Section -->
        <section class="section certs" id="education">
            <div class="container">
                <h2 class="section__title">Education</h2>
                <div class="certs__grid">
                    <article class="cert-card">
                        <div class="cert-card__icon"><i class="fa-solid fa-graduation-cap"></i></div>
                        <div class="cert-card__body">
                            <h3 class="cert-card__title">Web / Front-End Development</h3>
                            <p class="cert-card__meta">Life-Choices Academy • In Progress</p>
                        </div>
                    </article>
                    <article class="cert-card">
                        <div class="cert-card__icon"><i class="fa-solid fa-mobile-screen-button"></i></div>
                        <div class="cert-card__body">
                            <h3 class="cert-card__title">Responsive Web Design</h3>
                            <p class="cert-card__meta">Life-Choices Academy • Coursework</p>
                        </div>
                    </article>
                    <article class="cert-card">
                        <div class="cert-card__icon"><i class="fa-solid fa-laptop-code"></i></div>
                        <div class="cert-card__body">
                            <h3 class="cert-card__title">Project-Based Learning</h3>
                            <p class="cert-card__meta">Academy &amp; personal projects • Ongoing</p>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section class="section contact" id="contact">
            <div class="container contact__grid">
                <div class="contact__info">
                    <h2 class="section__title">Contact</h2>
                    <p class="section__lead">Have a project in mind? Get in touch.</p>
                    <ul class="contact__list">
                        <li><i class="fa-solid fa-envelope"></i> <a href="mailto:fredericksrasool11@gmail.com">fredericksrasool11@gmail.com</a></li>
                        <li><i class="fa-solid fa-location-dot"></i> Remote / Worldwide</li>
                        <li><i class="fa-solid fa-phone"></i> +27 67 802 0783</li>
                    </ul>
                    <div class="contact__socials">
                        <a href="https://www.linkedin.com/in/rasool-fredericks" target="_blank" rel="noopener" aria-label="LinkedIn"><i class="fab fa-linkedin"></i></a>
                        <a href="https://github.com/Rasoolking14" target="_blank" rel="noopener" aria-label="GitHub"><i class="fab fa-github"></i></a>
                    </div>
                </div>
                <div class="contact__form-wrap">
                    <!-- To receive messages in your inbox, create a free form at https://formspree.io
                         and paste the endpoint (e.g. https://formspree.io/f/xxxxxxx) into data-endpoint below.
                         If left empty, the form falls back to opening the visitor's email client. -->
                    <form class="contact-form" id="contactForm" data-endpoint="" novalidate>
                        <input type="hidden" name="_subject" value="New message from your portfolio">
                        <input type="text" name="_gotcha" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;opacity:0;height:0;width:0;">
                        <div class="form-row">
                            <label class="form-label" for="name">Name</label>
                            <input class="form-input" type="text" id="name" name="name" autocomplete="name" required>
                        </div>
                        <div class="form-row">
                            <label class="form-label" for="email">Email</label>
                            <input class="form-input" type="email" id="email" name="email" autocomplete="email" required>
                        </div>
                        <div class="form-row">
                            <label class="form-label" for="subject">Subject</label>
                            <input class="form-input" type="text" id="subject" name="subject" required>
                        </div>
                        <div class="form-row">
                            <label class="form-label" for="message">Message</label>
                            <textarea class="form-textarea" id="message" name="message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn--primary btn--full">Send Message</button>
                        <p class="form-status" id="formStatus" aria-live="polite"></p>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container footer__inner">
            <p class="footer__copy">&copy; 2026 Rasool Fredericks. All rights reserved.</p>
            <p class="footer__copy" style="opacity:0.7">Last updated: Oct 15, 2026</p>
            <button class="back-to-top" id="backToTop" aria-label="Back to top"><i class="fa-solid fa-arrow-up"></i></button>
        </div>
    </footer>

    <script src="<?php echo get_template_directory_uri(); ?>/assets/main.js"></script>
</body>
</html>






