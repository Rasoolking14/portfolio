﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rasool Fredericks - Senior Full-Stack Engineer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Montserrat:wght@600;700;800&family=Roboto:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/styles.css">
</head>
<body>
    <!-- Sticky Header & Navigation -->
    <header class="header">
        <nav class="nav container">
            <div class="nav__logo">
                <span class="nav__logo-text">Rasool Fredericks</span>
                <span class="nav__status">
                    <span class="nav__status-dot"></span>
                    <span class="nav__status-text">Available for Hire</span>
                </span>
            </div>
            <button class="nav__toggle" id="navToggle" aria-label="Open menu" aria-expanded="false">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <div class="nav__menu" id="navMenu">
                <ul class="nav__links">
                    <li><a href="#about" class="nav__link">About</a></li>
                    <li><a href="#skills" class="nav__link">Skills</a></li>
                    <li><a href="#projects" class="nav__link">Projects</a></li>
                    <li><a href="#certifications" class="nav__link">Certifications</a></li>
                    <li><a href="#contact" class="nav__link">Contact</a></li>
                </ul>
                <a href="<?php echo get_template_directory_uri(); ?>/assets/Rasool_Fredericks_Resume.pdf" target="_blank" rel="noopener" class="nav__cta">Resume / CV</a>
            </div>
        </nav>
    </header>

    <main>
        <!-- Hero Section -->
        <section class="hero" id="hero">
            <div class="container hero__grid">
                <div class="hero__content">
                    <h1 class="hero__headline">Senior Full-Stack Engineer crafting scalable web applications.</h1>
                    <p class="hero__subheadline">Specializing in cloud-native architecture, high-performance web systems, and modern full-stack developer experience.</p>
                    <div class="hero__actions">
                        <a href="#projects" class="btn btn--primary">View Work</a>
                        <a href="#contact" class="btn btn--outline">Contact Me</a>
                    </div>
                </div>
                <div class="hero__visual" aria-hidden="true">
                    <div class="hero__scene">
                        <div class="glass-card gc1">
                            <div class="gc__code">
                                <span class="gc__line">const api = new Gateway()</span>
                                <span class="gc__line">await api.auth()</span>
                                <span class="gc__line gc__line--accent">{ data: results }</span>
                            </div>
                        </div>
                        <div class="glass-card gc2">
                            <div class="gc__dots">
                                <span></span><span></span><span></span>
                            </div>
                            <span class="gc__label">Microservices</span>
                        </div>
                        <div class="glass-card gc3">
                            <div class="gc__bars">
                                <span></span><span></span><span></span><span></span>
                            </div>
                            <span class="gc__label">Edge Cache</span>
                        </div>
                        <div class="node n1"></div>
                        <div class="node n2"></div>
                        <div class="node n3"></div>
                        <div class="glow g1"></div>
                        <div class="glow g2"></div>
                    </div>
                </div>
            </div>
        </section>

        <!-- About Section -->
        <section class="section about" id="about">
            <div class="container about__grid">
                <div class="about__left">
                    <div class="avatar">
                        <div class="avatar__border"></div>
                        <div class="avatar__inner"><img class="avatar__img" src="<?php echo get_template_directory_uri(); ?>/assets/profile.png" alt="Rasool Fredericks portrait" loading="lazy"></div>
                    </div>
                </div>
                <div class="about__right">
                    <h2 class="section__title">About Me</h2>
                    <p class="section__lead">With over 8 years of engineering experience, I architect resilient full-stack systems and intuitive front-end interfaces. I focus on clean code, performant database design, and end-to-end cloud infrastructure.</p>
                    <p class="section__lead">I do not focus on forex trading alone — I also teach trading, helping others build solid technical and risk management skills to trade with confidence.</p>
                    <h3 class="about__subtitle">Professional Overview</h3>
                    <div class="about__cards">
                        <article class="info-card">
                            <div class="info-card__icon"><i class="fa-solid fa-bolt"></i></div>
                            <h4 class="info-card__title">8+ Years Experience</h4>
                            <p class="info-card__text">Building scalable enterprise SaaS applications.</p>
                        </article>
                        <article class="info-card">
                            <div class="info-card__icon"><i class="fa-solid fa-layer-group"></i></div>
                            <h4 class="info-card__title">Full-Stack Mastery</h4>
                            <p class="info-card__text">React, Next.js, Node.js, TypeScript &amp; PostgreSQL.</p>
                        </article>
                        <article class="info-card">
                            <div class="info-card__icon"><i class="fa-solid fa-cloud"></i></div>
                            <h4 class="info-card__title">Cloud Architecture</h4>
                            <p class="info-card__text">AWS, Docker, CI/CD pipelines, and microservices.</p>
                        </article>
                    </div>
                </div>
            </div>
        </section>

        <!-- Skills Section -->
        <section class="section skills" id="skills">
            <div class="container">
                <h2 class="section__title">Skills</h2>
                <div class="skills__grid">
                    <article class="skill-card">
                        <h3 class="skill-card__title">Frontend</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fab fa-react"></i> React</span>
                            <span class="skill-pill"><i class="fab fa-js-square"></i> Next.js</span>
                            <span class="skill-pill"><i class="fa-solid fa-code"></i> TypeScript</span>
                            <span class="skill-pill"><i class="fab fa-css3-alt"></i> Tailwind CSS</span>
                            <span class="skill-pill"><i class="fa-solid fa-diagram-project"></i> Redux</span>
                        </div>
                    </article>
                    <article class="skill-card">
                        <h3 class="skill-card__title">Backend</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fab fa-node-js"></i> Node.js</span>
                            <span class="skill-pill"><i class="fa-solid fa-server"></i> Express</span>
                            <span class="skill-pill"><i class="fab fa-python"></i> Python</span>
                            <span class="skill-pill"><i class="fa-solid fa-project-diagram"></i> GraphQL</span>
                            <span class="skill-pill"><i class="fa-solid fa-plug"></i> REST APIs</span>
                        </div>
                    </article>
                    <article class="skill-card">
                        <h3 class="skill-card__title">Database &amp; Cloud</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fa-solid fa-database"></i> PostgreSQL</span>
                            <span class="skill-pill"><i class="fa-solid fa-leaf"></i> MongoDB</span>
                            <span class="skill-pill"><i class="fab fa-aws"></i> AWS</span>
                            <span class="skill-pill"><i class="fab fa-docker"></i> Docker</span>
                            <span class="skill-pill"><i class="fa-solid fa-layer-group"></i> Redis</span>
                        </div>
                    </article>
                    <article class="skill-card">
                        <h3 class="skill-card__title">DevOps &amp; Tools</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fab fa-git-alt"></i> Git</span>
                            <span class="skill-pill"><i class="fa-solid fa-rocket"></i> CI/CD</span>
                            <span class="skill-pill"><i class="fa-solid fa-vial"></i> Jest</span>
                            <span class="skill-pill"><i class="fa-solid fa-cubes"></i> Kubernetes</span>
                            <span class="skill-pill"><i class="fa-solid fa-code-branch"></i> Terraform</span>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Projects Section -->
        <section class="section projects" id="projects">
            <div class="container">
                <h2 class="section__title">Projects</h2>
                <div class="projects__grid">
                    <article class="project-card">
                        <div class="project-card__thumb">
                            <svg viewBox="0 0 600 340" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                <defs>
                                    <linearGradient id="p1" x1="0" y1="0" x2="1" y2="1">
                                        <stop offset="0%" stop-color="#06B6D4"/>
                                        <stop offset="100%" stop-color="#3B82F6"/>
                                    </linearGradient>
                                </defs>
                                <rect width="600" height="340" rx="16" fill="#0F172A"/>
                                <circle cx="300" cy="170" r="90" stroke="url(#p1)" stroke-width="3" fill="none" opacity="0.8"/>
                                <circle cx="300" cy="170" r="40" stroke="url(#p1)" stroke-width="2" fill="none"/>
                                <g opacity="0.9">
                                    <line x1="300" y1="80" x2="300" y2="120" stroke="#06B6D4"/>
                                    <line x1="300" y1="220" x2="300" y2="260" stroke="#06B6D4"/>
                                    <line x1="210" y1="170" x2="250" y2="170" stroke="#06B6D4"/>
                                    <line x1="350" y1="170" x2="390" y2="170" stroke="#06B6D4"/>
                                </g>
                            </svg>
                        </div>
                        <div class="project-card__body">
                            <span class="project-card__tag">Full-Stack SaaS</span>
                            <h3 class="project-card__title">Enterprise Analytics Platform</h3>
                            <p class="project-card__desc">A multi-tenant analytics suite delivering real-time dashboards and role-based access. Built for scale with event-driven APIs and granular permissions.</p>
                            <div class="project-card__stack">
                                <span class="stack-pill">Next.js</span>
                                <span class="stack-pill">Node.js</span>
                                <span class="stack-pill">AWS</span>
                                <span class="stack-pill">PostgreSQL</span>
                            </div>
                            <div class="project-card__actions">
                                <a href="#" class="proj-link" aria-label="Live site"><i class="fa-solid fa-arrow-up-right-from-square"></i> Live Site</a>
                                <a href="#" class="proj-link" aria-label="GitHub repo"><i class="fab fa-github"></i> GitHub Repo</a>
                            </div>
                        </div>
                    </article>

                    <article class="project-card">
                        <div class="project-card__thumb">
                            <svg viewBox="0 0 600 340" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                <rect width="600" height="340" rx="16" fill="#0F172A"/>
                                <g stroke="#06B6D4" stroke-width="2" fill="none" opacity="0.9">
                                    <rect x="60" y="60" width="200" height="140" rx="12"/>
                                    <rect x="340" y="140" width="200" height="140" rx="12"/>
                                    <path d="M260 130 L340 170"/>
                                    <path d="M340 170 L260 210"/>
                                </g>
                                <circle cx="160" cy="130" r="8" fill="#3B82F6"/>
                                <circle cx="440" cy="210" r="8" fill="#3B82F6"/>
                            </svg>
                        </div>
                        <div class="project-card__body">
                            <span class="project-card__tag">FinTech Platform</span>
                            <h3 class="project-card__title">Real-Time Payments Gateway</h3>
                            <p class="project-card__desc">Secure, high-throughput payment orchestration with idempotent processing and automated reconciliation. Designed for PCI-aware workflows and observability.</p>
                            <div class="project-card__stack">
                                <span class="stack-pill">TypeScript</span>
                                <span class="stack-pill">Node.js</span>
                                <span class="stack-pill">Redis</span>
                                <span class="stack-pill">AWS</span>
                            </div>
                            <div class="project-card__actions">
                                <a href="#" class="proj-link"><i class="fa-solid fa-arrow-up-right-from-square"></i> Live Site</a>
                                <a href="#" class="proj-link"><i class="fab fa-github"></i> GitHub Repo</a>
                            </div>
                        </div>
                    </article>

                    <article class="project-card">
                        <div class="project-card__thumb">
                            <svg viewBox="0 0 600 340" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                <rect width="600" height="340" rx="16" fill="#0F172A"/>
                                <g stroke="#3B82F6" stroke-width="2" fill="none" opacity="0.9">
                                    <rect x="70" y="70" width="460" height="40" rx="8"/>
                                    <rect x="70" y="130" width="320" height="140" rx="8"/>
                                    <rect x="410" y="130" width="120" height="60" rx="8"/>
                                    <rect x="410" y="210" width="120" height="60" rx="8"/>
                                </g>
                                <circle cx="90" cy="90" r="4" fill="#06B6D4"/>
                                <circle cx="105" cy="90" r="4" fill="#3B82F6"/>
                                <circle cx="120" cy="90" r="4" fill="#94A3B8"/>
                            </svg>
                        </div>
                        <div class="project-card__body">
                            <span class="project-card__tag">Cloud Infrastructure</span>
                            <h3 class="project-card__title">Kubernetes-Native CI/CD Platform</h3>
                            <p class="project-card__desc">GitOps-driven delivery pipeline with preview environments, policy checks, and automated rollbacks. Accelerates safe releases with minimal toil.</p>
                            <div class="project-card__stack">
                                <span class="stack-pill">Kubernetes</span>
                                <span class="stack-pill">Terraform</span>
                                <span class="stack-pill">Docker</span>
                                <span class="stack-pill">AWS</span>
                            </div>
                            <div class="project-card__actions">
                                <a href="#" class="proj-link"><i class="fa-solid fa-arrow-up-right-from-square"></i> Live Site</a>
                                <a href="#" class="proj-link"><i class="fab fa-github"></i> GitHub Repo</a>
                            </div>
                        </div>
                    </article>

                    <article class="project-card">
                        <div class="project-card__thumb">
                            <svg viewBox="0 0 600 340" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                <rect width="600" height="340" rx="16" fill="#0F172A"/>
                                <g stroke="#06B6D4" stroke-width="2" fill="none" opacity="0.8">
                                    <path d="M120 90 L480 90 Q520 90 520 130 L520 210 Q520 250 480 250 L120 250 Q80 250 80 210 L80 130 Q80 90 120 90 Z"/>
                                    <line x1="80" y1="150" x2="520" y2="150" stroke="#06B6D4"/>
                                    <circle cx="480" cy="120" r="6" fill="#3B82F6"/>
                                    <circle cx="460" cy="120" r="6" fill="#06B6D4"/>
                                </g>
                            </svg>
                        </div>
                        <div class="project-card__body">
                            <span class="project-card__tag">Web Application</span>
                            <h3 class="project-card__title">Developer Experience Toolkit</h3>
                            <p class="project-card__desc">Type-safe CLI and internal tools to standardize scaffolding, migrations, and secrets. Improves consistency and reduces onboarding friction.</p>
                            <div class="project-card__stack">
                                <span class="stack-pill">TypeScript</span>
                                <span class="stack-pill">Node.js</span>
                                <span class="stack-pill">Redis</span>
                                <span class="stack-pill">Docker</span>
                            </div>
                            <div class="project-card__actions">
                                <a href="#" class="proj-link"><i class="fa-solid fa-arrow-up-right-from-square"></i> Live Site</a>
                                <a href="#" class="proj-link"><i class="fab fa-github"></i> GitHub Repo</a>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Certifications Section -->
        <section class="section certs" id="certifications">
            <div class="container">
                <h2 class="section__title">Certifications</h2>
                <div class="certs__grid">
                    <article class="cert-card">
                        <div class="cert-card__icon"><i class="fab fa-aws"></i></div>
                        <div class="cert-card__body">
                            <h3 class="cert-card__title">AWS Certified Solutions Architect - Associate</h3>
                            <p class="cert-card__meta">Issued: 2024 â€¢ Amazon Web Services</p>
                        </div>
                    </article>
                    <article class="cert-card">
                        <div class="cert-card__icon"><i class="fa-solid fa-certificate"></i></div>
                        <div class="cert-card__body">
                            <h3 class="cert-card__title">Meta Senior Full-Stack Engineer Certificate</h3>
                            <p class="cert-card__meta">Issued: 2025 â€¢ Meta</p>
                        </div>
                    </article>
                    <article class="cert-card">
                        <div class="cert-card__icon"><i class="fa-solid fa-cubes"></i></div>
                        <div class="cert-card__body">
                            <h3 class="cert-card__title">Certified Kubernetes Application Developer (CKAD)</h3>
                            <p class="cert-card__meta">Issued: 2023 â€¢ CNCF/Linux Foundation</p>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section class="section contact" id="contact">
            <div class="container contact__grid">
                <div class="contact__info">
                    <h2 class="section__title">Contact</h2>
                    <p class="section__lead">Have a project in mind? Get in touch.</p>
                    <ul class="contact__list">
                        <li><i class="fa-solid fa-envelope"></i> <a href="mailto:fredericksrasool11@gmail.com">fredericksrasool11@gmail.com</a></li>
                        <li><i class="fa-solid fa-location-dot"></i> Remote / Worldwide</li>
                        <li><i class="fa-solid fa-phone"></i> 0678020783</li>
                    </ul>
                    <div class="contact__socials">
                        <a href="https://www.linkedin.com/" target="_blank" rel="noopener" aria-label="LinkedIn"><i class="fab fa-linkedin"></i></a>
                        <a href="https://github.com/" target="_blank" rel="noopener" aria-label="GitHub"><i class="fab fa-github"></i></a>
                        <a href="https://x.com/" target="_blank" rel="noopener" aria-label="X (Twitter)"><i class="fab fa-x-twitter"></i></a>
                    </div>
                </div>
                <div class="contact__form-wrap">
                    <form class="contact-form" id="contactForm" novalidate>
                        <div class="form-row">
                            <label class="form-label" for="name">Name</label>
                            <input class="form-input" type="text" id="name" name="name" autocomplete="name" required>
                        </div>
                        <div class="form-row">
                            <label class="form-label" for="email">Email</label>
                            <input class="form-input" type="email" id="email" name="email" autocomplete="email" required>
                        </div>
                        <div class="form-row">
                            <label class="form-label" for="subject">Subject</label>
                            <input class="form-input" type="text" id="subject" name="subject" required>
                        </div>
                        <div class="form-row">
                            <label class="form-label" for="message">Message</label>
                            <textarea class="form-textarea" id="message" name="message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn--primary btn--full">Send Message</button>
                        <p class="form-status" id="formStatus" aria-live="polite"></p>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container footer__inner">
            <p class="footer__copy">&copy; 2026 Rasool Fredericks. All rights reserved.</p>
            <p class="footer__copy" style="opacity:0.7">Last updated: Oct 12, 2026</p>
            <button class="back-to-top" id="backToTop" aria-label="Back to top"><i class="fa-solid fa-arrow-up"></i></button>
        </div>
    </footer>

    <script src="<?php echo get_template_directory_uri(); ?>/assets/main.js"></script>
</body>
</html>






