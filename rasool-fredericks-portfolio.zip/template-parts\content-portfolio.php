<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rasool Fredericks - Senior Full-Stack Engineer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Montserrat:wght@600;700;800&family=Roboto:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/styles.css">
    <script>
        (function () {
            try {
                if (localStorage.getItem('rf-theme') === 'light') {
                    document.documentElement.setAttribute('data-theme', 'light');
                }
            } catch (e) {}
        })();
    </script>
</head>
<body>
    <canvas id="starfield" aria-hidden="true"></canvas>
    <!-- Sticky Header & Navigation -->
    <header class="header">
        <nav class="nav container">
            <div class="nav__logo">
                <span class="nav__logo-text">Rasool Fredericks</span>
                <span class="nav__status">
                    <span class="nav__status-dot"></span>
                    <span class="nav__status-text">Available for Hire</span>
                </span>
            </div>
            <div class="nav__actions">
                <button class="theme-toggle" id="themeToggle" type="button" aria-label="Toggle light and dark mode" aria-pressed="false">
                    <i class="fa-solid fa-sun"></i>
                </button>
                <button class="nav__toggle" id="navToggle" aria-label="Open menu" aria-expanded="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <div class="nav__menu" id="navMenu">
                    <ul class="nav__links">
                        <li><a href="#about" class="nav__link">About</a></li>
                        <li><a href="#experience" class="nav__link">Experience</a></li>
                        <li><a href="#skills" class="nav__link">Skills</a></li>
                        <li><a href="#projects" class="nav__link">Projects</a></li>
                        <li><a href="#certifications" class="nav__link">Certifications</a></li>
                        <li><a href="#contact" class="nav__link">Contact</a></li>
                    </ul>
                    <a href="<?php echo get_template_directory_uri(); ?>/assets/Rasool_Fredericks_Resume.pdf" target="_blank" rel="noopener" class="nav__cta">Resume / CV</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <!-- Hero Section -->
        <section class="hero" id="hero">
            <div class="container hero__grid">
                <div class="hero__content">
                    <h1 class="hero__headline">Senior Full-Stack Engineer crafting scalable web applications.</h1>
                    <p class="hero__subheadline">Specializing in cloud-native architecture, high-performance web systems, and modern full-stack developer experience.</p>
                    <div class="hero__actions">
                        <a href="#projects" class="btn btn--primary">View Work</a>
                        <a href="#contact" class="btn btn--outline">Contact Me</a>
                    </div>
                </div>
                <div class="hero__visual" aria-hidden="true">
                    <div class="hero__scene">
                        <div class="glass-card gc1">
                            <div class="gc__code">
                                <span class="gc__line">const api = new Gateway()</span>
                                <span class="gc__line">await api.auth()</span>
                                <span class="gc__line gc__line--accent">{ data: results }</span>
                            </div>
                        </div>
                        <div class="glass-card gc2">
                            <div class="gc__dots">
                                <span></span><span></span><span></span>
                            </div>
                            <span class="gc__label">Microservices</span>
                        </div>
                        <div class="glass-card gc3">
                            <div class="gc__bars">
                                <span></span><span></span><span></span><span></span>
                            </div>
                            <span class="gc__label">Edge Cache</span>
                        </div>
                        <div class="node n1"></div>
                        <div class="node n2"></div>
                        <div class="node n3"></div>
                        <div class="glow g1"></div>
                        <div class="glow g2"></div>
                    </div>
                </div>
            </div>
        </section>

        <!-- About Section -->
        <section class="section about" id="about">
            <div class="container about__grid">
                <div class="about__left">
                    <div class="avatar" id="avatarFlip" role="button" tabindex="0" aria-pressed="false" aria-label="Flip between formal and casual photo">
                        <div class="avatar__border"></div>
                        <div class="avatar__flip">
                            <div class="avatar__face avatar__face--front"><img class="avatar__img" src="<?php echo get_template_directory_uri(); ?>/assets/profile.png" alt="Rasool Fredericks portrait" loading="lazy"></div>
                            <div class="avatar__face avatar__face--back"><img class="avatar__img" src="<?php echo get_template_directory_uri(); ?>/assets/profile-casual.png" alt="Rasool Fredericks casual portrait" loading="lazy" onerror="this.onerror=null;this.src='<?php echo get_template_directory_uri(); ?>/assets/profile.png'"></div>
                        </div>
                    </div>
                </div>
                <div class="about__right">
                    <h2 class="section__title">About Me</h2>
                    <p class="section__lead">With over 8 years of engineering experience, I architect resilient full-stack systems and intuitive front-end interfaces. I focus on clean code, performant database design, and end-to-end cloud infrastructure.</p>
                    <p class="section__lead">I do not focus on forex trading alone — I also teach trading, helping others build solid technical and risk management skills to trade with confidence.</p>
                    <h3 class="about__subtitle">Professional Overview</h3>
                    <div class="about__cards">
                        <article class="info-card">
                            <div class="info-card__icon"><i class="fa-solid fa-bolt"></i></div>
                            <h4 class="info-card__title">8+ Years Experience</h4>
                            <p class="info-card__text">Building scalable enterprise SaaS applications.</p>
                        </article>
                        <article class="info-card">
                            <div class="info-card__icon"><i class="fa-solid fa-layer-group"></i></div>
                            <h4 class="info-card__title">Full-Stack Mastery</h4>
                            <p class="info-card__text">React, Next.js, Node.js, TypeScript &amp; PostgreSQL.</p>
                        </article>
                        <article class="info-card">
                            <div class="info-card__icon"><i class="fa-solid fa-cloud"></i></div>
                            <h4 class="info-card__title">Cloud Architecture</h4>
                            <p class="info-card__text">AWS, Docker, CI/CD pipelines, and microservices.</p>
                        </article>
                    </div>
                </div>
            </div>
        </section>

        <!-- Experience Section -->
        <section class="section experience" id="experience">
            <div class="container">
                <h2 class="section__title">Experience</h2>
                <p class="section__lead">A track record of architecting, shipping and scaling production systems.</p>
                <ol class="timeline">
                    <li class="timeline__item">
                        <div class="timeline__marker" aria-hidden="true"></div>
                        <div class="timeline__content">
                            <div class="timeline__head">
                                <h3 class="timeline__role">Senior Full-Stack Engineer</h3>
                                <span class="timeline__period">2019 &ndash; Present</span>
                            </div>
                            <ul class="timeline__points">
                                <li>Architect and deliver scalable, multi-tenant SaaS platforms with event-driven APIs and granular role-based access control.</li>
                                <li>Design high-throughput, idempotent payment and data workflows with observability and automated reconciliation.</li>
                                <li>Build Kubernetes-native CI/CD pipelines using GitOps, preview environments, policy checks, and automated rollbacks.</li>
                                <li>Lead cloud infrastructure on AWS with Docker, CI/CD automation, and microservices architecture.</li>
                            </ul>
                        </div>
                    </li>
                    <li class="timeline__item">
                        <div class="timeline__marker" aria-hidden="true"></div>
                        <div class="timeline__content">
                            <div class="timeline__head">
                                <h3 class="timeline__role">Full-Stack Engineer</h3>
                                <span class="timeline__period">2016 &ndash; 2019</span>
                            </div>
                            <ul class="timeline__points">
                                <li>Developed and maintained modern web applications using React, Node.js, and PostgreSQL.</li>
                                <li>Improved front-end performance and developer experience through type-safe tooling and standardized scaffolding.</li>
                                <li>Collaborated on database design, API development, and deployment automation.</li>
                            </ul>
                        </div>
                    </li>
                </ol>
            </div>
        </section>

        <!-- Skills Section -->
        <section class="section skills" id="skills">
            <div class="container">
                <h2 class="section__title">Skills</h2>
                <div class="skills__grid">
                    <article class="skill-card">
                        <h3 class="skill-card__title">Frontend</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fab fa-react"></i> React</span>
                            <span class="skill-pill"><i class="fab fa-js-square"></i> Next.js</span>
                            <span class="skill-pill"><i class="fa-solid fa-code"></i> TypeScript</span>
                            <span class="skill-pill"><i class="fab fa-css3-alt"></i> Tailwind CSS</span>
                            <span class="skill-pill"><i class="fa-solid fa-diagram-project"></i> Redux</span>
                        </div>
                    </article>
                    <article class="skill-card">
                        <h3 class="skill-card__title">Backend</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fab fa-node-js"></i> Node.js</span>
                            <span class="skill-pill"><i class="fa-solid fa-server"></i> Express</span>
                            <span class="skill-pill"><i class="fab fa-python"></i> Python</span>
                            <span class="skill-pill"><i class="fa-solid fa-project-diagram"></i> GraphQL</span>
                            <span class="skill-pill"><i class="fa-solid fa-plug"></i> REST APIs</span>
                        </div>
                    </article>
                    <article class="skill-card">
                        <h3 class="skill-card__title">Database &amp; Cloud</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fa-solid fa-database"></i> PostgreSQL</span>
                            <span class="skill-pill"><i class="fa-solid fa-leaf"></i> MongoDB</span>
                            <span class="skill-pill"><i class="fab fa-aws"></i> AWS</span>
                            <span class="skill-pill"><i class="fab fa-docker"></i> Docker</span>
                            <span class="skill-pill"><i class="fa-solid fa-layer-group"></i> Redis</span>
                        </div>
                    </article>
                    <article class="skill-card">
                        <h3 class="skill-card__title">DevOps &amp; Tools</h3>
                        <div class="skill-card__items">
                            <span class="skill-pill"><i class="fab fa-git-alt"></i> Git</span>
                            <span class="skill-pill"><i class="fa-solid fa-rocket"></i> CI/CD</span>
                            <span class="skill-pill"><i class="fa-solid fa-vial"></i> Jest</span>
                            <span class="skill-pill"><i class="fa-solid fa-cubes"></i> Kubernetes</span>
                            <span class="skill-pill"><i class="fa-solid fa-code-branch"></i> Terraform</span>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Projects Section -->
        <section class="section projects" id="projects">
            <div class="container">
                <h2 class="section__title">Projects</h2>
                <div class="projects__grid">
                    <article class="project-card">
                        <div class="project-card__thumb">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/project-hr-system.png" alt="ModernTech HR Management System dashboard" loading="lazy">
                        </div>
                        <div class="project-card__body">
                            <span class="project-card__tag">Full-Stack HR Platform</span>
                            <h3 class="project-card__title">ModernTech HR Management System</h3>
                            <p class="project-card__desc">A full-stack HR management app for tracking employees, attendance, payroll, time off, and performance reviews. Built with role-based JWT auth and a normalised MySQL schema. I owned the payroll module.</p>
                            <div class="project-card__stack">
                                <span class="stack-pill">Node.js</span>
                                <span class="stack-pill">Express</span>
                                <span class="stack-pill">MySQL</span>
                                <span class="stack-pill">JWT</span>
                            </div>
                            <div class="project-card__actions">
                                <a href="https://moderntech-hr-frontend.onrender.com" target="_blank" rel="noopener" class="proj-link" aria-label="Live site"><i class="fa-solid fa-arrow-up-right-from-square"></i> Live Site</a>
                                <a href="https://github.com/nikitamullerr/Group-4_HRSystem_Project2" target="_blank" rel="noopener" class="proj-link" aria-label="GitHub repo"><i class="fab fa-github"></i> GitHub Repo</a>
                            </div>
                        </div>
                    </article>

                    <article class="project-card">
                        <div class="project-card__thumb">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/project-applydirect.png" alt="ApplyDirect-SA application portal homepage" loading="lazy">
                        </div>
                        <div class="project-card__body">
                            <span class="project-card__tag">Full-Stack Web Platform</span>
                            <h3 class="project-card__title">ApplyDirect-SA</h3>
                            <p class="project-card__desc">A centralised tertiary application portal and career directory for South African students. Aggregates course details and institutional requirements with dynamic search and filtering.</p>
                            <div class="project-card__stack">
                                <span class="stack-pill">Vue.js</span>
                                <span class="stack-pill">Bootstrap 5</span>
                                <span class="stack-pill">Express</span>
                                <span class="stack-pill">MySQL</span>
                            </div>
                            <div class="project-card__actions">
                                <a href="https://github.com/stephanbennett42-ctrl/applydirect-sa" target="_blank" rel="noopener" class="proj-link" aria-label="GitHub repo"><i class="fab fa-github"></i> GitHub Repo</a>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Certifications Section -->
        <section class="section certs" id="certifications">
            <div class="container">
                <h2 class="section__title">Certifications</h2>
                <div class="certs__grid">
                    <article class="cert-card">
                        <div class="cert-card__icon"><i class="fab fa-aws"></i></div>
                        <div class="cert-card__body">
                            <h3 class="cert-card__title">AWS Certified Solutions Architect - Associate</h3>
                            <p class="cert-card__meta">Issued: 2024 • Amazon Web Services</p>
                        </div>
                    </article>
                    <article class="cert-card">
                        <div class="cert-card__icon"><i class="fa-solid fa-certificate"></i></div>
                        <div class="cert-card__body">
                            <h3 class="cert-card__title">Meta Senior Full-Stack Engineer Certificate</h3>
                            <p class="cert-card__meta">Issued: 2025 • Meta</p>
                        </div>
                    </article>
                    <article class="cert-card">
                        <div class="cert-card__icon"><i class="fa-solid fa-cubes"></i></div>
                        <div class="cert-card__body">
                            <h3 class="cert-card__title">Certified Kubernetes Application Developer (CKAD)</h3>
                            <p class="cert-card__meta">Issued: 2023 • CNCF/Linux Foundation</p>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section class="section contact" id="contact">
            <div class="container contact__grid">
                <div class="contact__info">
                    <h2 class="section__title">Contact</h2>
                    <p class="section__lead">Have a project in mind? Get in touch.</p>
                    <ul class="contact__list">
                        <li><i class="fa-solid fa-envelope"></i> <a href="mailto:fredericksrasool11@gmail.com">fredericksrasool11@gmail.com</a></li>
                        <li><i class="fa-solid fa-location-dot"></i> Remote / Worldwide</li>
                        <li><i class="fa-solid fa-phone"></i> 0678020783</li>
                    </ul>
                    <div class="contact__socials">
                        <a href="https://www.linkedin.com/in/rasool-fredericks" target="_blank" rel="noopener" aria-label="LinkedIn"><i class="fab fa-linkedin"></i></a>
                        <a href="https://github.com/Rasoolking14" target="_blank" rel="noopener" aria-label="GitHub"><i class="fab fa-github"></i></a>
                        <a href="https://x.com/" target="_blank" rel="noopener" aria-label="X (Twitter)"><i class="fab fa-x-twitter"></i></a>
                    </div>
                </div>
                <div class="contact__form-wrap">
                    <!-- To receive messages in your inbox, create a free form at https://formspree.io
                         and paste the endpoint (e.g. https://formspree.io/f/xxxxxxx) into data-endpoint below.
                         If left empty, the form falls back to opening the visitor's email client. -->
                    <form class="contact-form" id="contactForm" data-endpoint="" novalidate>
                        <input type="hidden" name="_subject" value="New message from your portfolio">
                        <input type="text" name="_gotcha" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;opacity:0;height:0;width:0;">
                        <div class="form-row">
                            <label class="form-label" for="name">Name</label>
                            <input class="form-input" type="text" id="name" name="name" autocomplete="name" required>
                        </div>
                        <div class="form-row">
                            <label class="form-label" for="email">Email</label>
                            <input class="form-input" type="email" id="email" name="email" autocomplete="email" required>
                        </div>
                        <div class="form-row">
                            <label class="form-label" for="subject">Subject</label>
                            <input class="form-input" type="text" id="subject" name="subject" required>
                        </div>
                        <div class="form-row">
                            <label class="form-label" for="message">Message</label>
                            <textarea class="form-textarea" id="message" name="message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn--primary btn--full">Send Message</button>
                        <p class="form-status" id="formStatus" aria-live="polite"></p>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container footer__inner">
            <p class="footer__copy">&copy; 2026 Rasool Fredericks. All rights reserved.</p>
            <p class="footer__copy" style="opacity:0.7">Last updated: Oct 12, 2026</p>
            <button class="back-to-top" id="backToTop" aria-label="Back to top"><i class="fa-solid fa-arrow-up"></i></button>
        </div>
    </footer>

    <script src="<?php echo get_template_directory_uri(); ?>/assets/main.js"></script>
</body>
</html>






